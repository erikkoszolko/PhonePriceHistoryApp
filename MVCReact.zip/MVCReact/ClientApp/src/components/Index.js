import React, { Component } from 'react';

export class Markas extends Component {
  static displayName = Markas.name;

  render () {
    return (
      <div>
        <h1>Marki</h1>
       
        <br></br>
          
         </div>
    );
  }
}