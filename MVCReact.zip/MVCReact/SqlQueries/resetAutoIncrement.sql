﻿USE [aspnet-MVCReact-53bc9b9d-9d6a-45d4-8429-2a2761773502]
GO

/****** Object: Table [dbo].[Products] Script Date: 04.01.2022 14:39:33 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

DBCC CHECKIDENT (Markas, RESEED, 0)


